

<div class="men"> 
	<div class="container"> 
	    <div class="register"> 
			   <div class="col-md-6 login-left"> 
			  	 <h3>Daftar Menjadi Pelelang Baru</h3> 
				 <p>Untuk melelang barang anda silahkan daftar diri anda di form bawah ini</p> 
				 <a class="acount-btn" href="index.php/web/register">Buat Akun Baru</a>
			   </div> 
			   <div class="col-md-6 login-right"> 
			  	<h3>Login Sebagai PeLelang</h3> 
				<p>Silahkan login dengan username dan password yang telah di dafar</p> 
				<form method="post" action="index.php/login_pelelang"> 
				  <div> 
					<span>Username<label>*</label></span> 
					<input type="text" name="username"> 
				  </div> 
				  <div> 
					<span>Password<label>*</label></span> 
					<input type="password" name="password"> 
					<input type="hidden" name="status" value="1"> 
				  </div> 
				  <a class="forgot" href="#">Forgot Your Password?</a> 
				  <input type="submit" value="Login"> 
			    </form> 
			   </div>	
			   <div class="clearfix"> </div> 
		</div> 
	 </div> 
</div> 