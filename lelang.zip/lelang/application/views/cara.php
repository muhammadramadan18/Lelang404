<div class="men"> 
	<div class="container"> 
	    <div class="col-md-12 register"> 
		  	  <center><h1>CARA IKUT LELANG</h1></center>

<div class="step-wrap">
	<h3 class="step-title">Buka websitenya</h3>
    <div class="step-desc"><p>Silahkan membuka website kami di </p></div>
</div>
<div class="step-wrap">
	<h3 class="step-title">Registrasi</h3>
    <div class="step-desc"><ul>
    	<li>Silahkan klik button LOGIN.  </li>
		<li>Isi data yang ada pada form registrasi.</li>
		<li>Silahkan menunggu konfirmasi email bahwa account anda telah aktif.</li>
        <li>Setelah account anda aktif, silahkan lengkapi data yang ada Tab My Profle.</li>
        </ul>
	</div>
</div><div class="step-wrap">
	<h3 class="step-title">Pembelian NPL</h3>
    <div class="step-desc">
    	<ul>
        	<li>Jika anda tertarik mengikuti lelang,anda harus memiliki NPL </li>
            <li>Pembelian NPL dapat dilakukan dengan Klik Tab My Profile Lalu pilih menu NPL</li>
            <li>Pilih Kategori yang anda inginkan dan juga jumlah NPL yang ingin anda beli</li>
            <li>Setelah melakukan pembelian NPL,silahkan setor jaminan ke BCA pada no rekening 4281.51.52.62 BCA Cab Sunter Mall atas nama PT Balai Lelang Serasi.<br />
                    - Rp 5 juta untuk NPL satuan (1 NPL dapat memenangkan 1 mobil).<br />
					- Rp 1 juta untuk NPL satuan (1 NPL dapat memenangkan 1 motor).<br />
					- Rp 100 ribu untuk NPL satuan (1 NPL dapat memenangkan 1 motor/Gadget).
            <li>Setelah melakukan pembayaran, anda diharuskan melakukan konfirmasi di Menu My profile lalu pilih NPL dan pilih Konfirmasi </li>
            <li>Setelah melakukan konfirmasi pembayaran, silahkan menunggu email pemberitahuan bahwa NPL anda telah aktif </li>
        </ul>
    </div>
</div>
<div class="step-wrap">
	<h3 class="step-title">Melakukan Penawaran</h3>
    <div class="step-desc">
    	<ul>
        	<li>Anda dapat melakukan penawaran langsung dari menu Home dan pilih barang yang ingin anda tawar lalu Klik TAWAR.</li>
			<li>Kelipatan tawar mobil adalah Rp.500.000,- untuk motor Rp.100.000,- dan untuk gadget Rp.50.000,-</li>
            <li>Setelah klik anda akan masuk ke menu barang tersebut dan Klik Bid, namun apabila anda ingin menawar lebih tinggi dari harga yang tertera, anda bisa edit harga tersebut lalu klik BID</li>
            <li>Anda juga dapat memilih 'Automatic Bidding'. Di fitur ini anda dapat memasukan jumlahh tawaran maksimal anda sehingga anda tidak perlu melakukan penawaran terus menerus.</li>
            <!--<li>Apabila terdapat penawaran didetik-detik terakhir sebelum penawaran unit ditutup maka sistem secara otomatis akan memberikan penambahan waktu.</li>-->
            </ul>

    </div>
</div>
<div class="step-wrap">
	<h3 class="step-title">Jika KALAH Lelang </h3>
    <div class="step-desc">
    	<ul>
        	<li>Jika PENAWARAN atas OBYEK LELANG sudah KALAH, NPL dapat dialihkan untuk menawar unit lain</li>
         </ul>

    </div>
</div>
<div class="step-wrap">
	<h3 class="step-title">Menang / Tidak Menang</h3>
    <div class="step-desc">
    	<ul>
      	<li>Lakukan pelunasan atas unit yang Anda menangkan via Bank pada nomor rekening yang sama seperti pada saat setor jaminan.</li>
		<li>Biaya Administrasi Pemenang untuk 1 unit mobil adalah Rp.1.750.000,- untuk 1 unit motor Rp.250.000,- untuk 1 unit gadget Rp.250.000,- dan (Untuk Dekstop + Monitor Rp. 350.000,-)</li>
		<li>Unit bisa diserah terimakan setelah pelunasan dilakukan oleh pemenang.</li>
        <!--li>Apabila unit gadget yang dimenangkan ingin dibantu pengirimannya ke rumah pemenang serta detail informasi mekanisme pengambilan unit gadget dimohon untuk membaca page Syarat Ketentuan</li-->
		<li>Jika anda belum menang pada salah satu unit, jangan sedih,lakukan penawaran pada unit lainnya. </li>
		<li>Jika sampai lelang selesai Anda tidak memenangkan satu unitpun, maka uang jaminan akan dikembalikan via transfer bank ke nomor rekening yang tercantum saat pendaftaran tanpa potongan apapun.</li>
            </ul>
    </div>
</div>
				</div> 
		   </div> 
	 </div> 
</div> 