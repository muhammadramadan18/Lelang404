<div class="men"> 
	<div class="container"> 
	    <div class="col-md-12 register"> 
		  	  <form method="post" action="index.php/web/proses_register"> 
				 <div class="register-top-grid"> 
					<h3>Isi Data Pelelang</h3> 
					 <div> 
						<span>Nama<label>*</label></span> 
						<input type="text" name="nama_pelelang"> 
					 </div> 
					 
					 <div> 
						 <span>No Hp<label>*</label></span> 
						 <input type="text" name="no_hp"> 
					 </div> 
					 <div> 
						 <span>Alamat<label>*</label></span> 
						 <textarea  name="alamat" style="margin-left: 0px; margin-right: 0px; width: 1046px; margin-top: 0px; margin-bottom: 0px; height: 93px; "></textarea>
					 </div> 
					 <div class="clearfix"> </div> 
					   <a class="news-letter" href="#"> 
						 <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i> </i>Sign Up for Newsletter</label> 
					   </a> 
					 </div> 
				     <div class="register-bottom-grid"> 
						    <h3>Data Login</h3> 
							 <div> 
								<span>Username<label>*</label></span> 
								<input type="text" name="username"> 
							 </div> 
							 <div> 
								<span>Password<label>*</label></span> 
								<input type="password" name="password"> 
							 </div> 
							 <div class="clearfix"> </div> 
					 </div> 
				
				<div class="clearfix"> </div> 
				<div class="register-but"> 
				 
					   <input type="submit" value="Kirim" class="btn btn-success"> 
					   <div class="clearfix"> </div> 
				   </form> 
				</div> 
		   </div> 
	 </div> 
</div> 