<div class="men"> 
	<div class="container"> 
	    <div class="col-md-12 register"> 
		  	<center><h1>KETENTUAN UMUM</h1></center>
<h2 class="content-subheader">INFORMASI</h2>
<ol>
<li>Proses penawaran : tertutup via web </li>
<li>Alamat web : http://online.ibid.co.id </li>
<li>Pembayaran : Seluruh pembayaran ( Jaminan / Pelunasan ) ditujukan kepada Rekening PT Balai Lelang Serasi di BCA Cab Sunter Mall Jakarta     No. Rekening :  4281.51.52.62</li>
<li>Info: Tlp  (021) 735.5999, Fax. (021) 7289 5566, SMS 0857 1863 5544 dan Pin BBM 7CEAF292. Email : info.ibid@ibid.astra.co.id</li>
</ol>
<h2 class="content-subheader">Peraturan</h2>
<ol>
  <li> <b> PADA SAAT OPEN HOUSE </b>
  		<ol>
        	<li>Peminat dapat melihat unit yang akan dijual selama acara open house.</li>
            <li>Peminat  hanya diperkenankan memeriksa kondisi fisik dan kelengkapan kendaraan / motor / gadget, tidak diperkenankan untuk melakukan bongkar pasang atau sejenisnya yang dapat merusak unit.</li>
            <li>Peminat  dilarang  mengambil atau merusak atribut, nomor, tulisan atau tanda-tanda yang menempel pada unit.</li>
        </ol>
  </li>
  <li> <b>KONDISI OBYEK YANG DIJUAL</b>
  <ol> 
  		<li>Kondisi unit yang dijual adalah <b>"sebagaimana adanya".</b></li>
        <li>Peserta wajib meneliti unit yang akan ditawar serta mengetahui kondisi unitnya. Jika terdapat kekurangan atau cacat baik yang terlihat maupun tak terlihat bukan menjadi tanggung  jawab penjual .</li>
        <li>Untuk memudahkan para peminat , panitia menyediakan daftar lot yang berisi data unit yang dapat dijadikan panduan dalam memilih.</li>
  </ol>
  </li>
  <li> <b>SEBELUM MENGIKUTI LELANG</b>
  <ol>
  		<li>Peminat yang bermaksud mengajukan penawaran  harus terlebih dahulu menyetor uang jaminan sebesar <b>Rp 5.000.000,- (lima juta rupiah) / unit mobil, Rp.1.000.000,- (satu juta rupiah) / unit motor dan Rp.100.000,- (seratus ribu rupiah) / unit gadget </b>serta melakukan pendaftaran di web.</li>
        <li>Uang jaminan disetorkan ke Rekening <b>PT Balai Lelang Serasi</b> yang harus sudah efektif pada saat pendaftaran peserta Lelang.</li>
        <li>Bukti setoran serta copy identitas dapat dikirim via : <br />
            -	email ke : info.ibid@ibid.astra.co.id <br />
            -	Fax.021.7289 5566
		</li>
        <li>Peminat dapat melakukan login ke situs online.ibid.co.id untuk memperoleh Nomor Peserta  (NPL) dengan melampirkan bukti setoran jaminan serta scan identitas diri (KTP/SIM) yang masih berlaku (ketika pendaftaran detail di web).</li>
  </ol>
  </li>
 <li> <b>PADA SAAT MENGIKUTI LELANG</b>
  <ol>
  		<li>Hanya peserta Lelang yang memiliki NPL yang bisa mengajukan penawar.</li>
        <li>Lelang akan dibuka dengan harga dasar dan kemudian bisa dinaikan dengan kelipatan Rp 500.000 ( lima ratus ribu rupiah)untuk mobil, Rp. 100.000,- (seratus ribu rupiah) untuk motor dan Rp. 50.000,- (lima puluh ribu rupiah) untuk gadget..</li>
        <li>Pemenang Lelang adalah peserta yang mengajuan harga penawaran tertinggi.</li>
        <li>Pemenang sepenuhnya bertanggung jawab atas apa yang ia tawar dan ia menangkan.</li>
        <!--li>Peserta yang dinilai mengacaukan jalannya Lelang akan didiskualifikasi / dikeluarkan dari acara lelang.</li-->
  </ol>
  </li>
  <li> <b>PENAWARAN</b>
  <ol>
  		<li>Hanya peserta  yang memiliki NPL yang dapat melakukan penawaran di web.</li>
        <li>Harga penawaran adalah kelipatan <b>Rp.500.000,-</b> untuk mobil, <b>Rp.100.000,-</b> untuk motor dan <b>Rp.50.000,-</b> untuk gadget di atas harga dasar.</li>
        <li>Pemenang  adalah peserta dengan pengajuan  harga penawaran tertinggi.</li>
        <li>Peserta  hanya berhak memenangkan unit sebanyak jumlah NPL yang dimiliki</li>
        <!--<li>Apabila terdapat penawaran didetik-detik terakhir sebelum penawaran unit ditutup maka sistem secara otomatis akan memberikan penambahan waktu.</li>-->
  </ol>
  </li>
  <li> <b>PEMENANG</b>
  <ol>
  		<li>Pemenang  adalah penawar tertinggi pada setiap unit yang dijual.</li>
        <li>Pemenang dikenakan biaya administrasi sebesar Rp.1.750.000 (satu juta dua ratus lima puluh ribu rupiah) per unit mobil yang dimenangkan.</li>
        <li>Pemenang dikenakan biaya administrasi sebesar Rp.250.000 (dua ratus ribu rupiah) per unit motor dan gadget yang dimenangkan (Untuk Lot Desktop + Monitor biaya admin dikenakan sebesar Rp. 350.000).</li>
        <li>Pemenang  harus melunasi total harga unit yang dimenangkan selambat-lambatnya 3 (tiga) hari kerja dan biaya admin pemenang lelang setelah tanggal pelaksanaan.</li>
        <li>Pemenang  yang sudah membayar lunas harga  dan efektif di rekening, dapat melakukan pengmbilan unit dan dokumen.</li>
        <li>Pemenang  yang membatalkan diri pada satu atau beberapa unit yang dimenangkan atau tidak melunasi pembayaran sesuai dengan waktu yang telah ditetapkan dinyatakan wanprestasi (kemenangannya batal) dan uang jaminan <b>hangus.</b></li>
        <li>Pengembalian uang jaminan 100% akan ditransfer ke rekening peserta sebagaimana tercantum dalam form pendaftaran apabila peserta tidak memenangkan unit.</li>
        <li>Apabila sampai dengan 2 hari kerja setelah batas pelunasan yang telah ditetapkan unit belum juga diambil pemenang, segala kerusakan dan atau kehilangan sepenuhnya menjadi tanggung jawab pemenang.</li>
  </ol>
  </li>
  <li> <b>FORCE MAJOURE</b>
  <ol>
  		Apabila terjadi FORCE MAJOURE seperti bencana alam, kerusuhan masa dan tindakan pemerintah dalam bidang moneter, maka segala akibat dan atau kerugian yang timbul menjadi tanggung jawab pemenang.
  </ol>
  </li>
  <li> <b>KETENTUAN LAIN-LAIN</b>
  <ol>
  		<li>Biaya yang timbul dalam rangka peralihan hak atau pengambilan / pemindahan kendaraan menjadi tanggung jawab pemenang.</li>
        <li>Objek  lelang tidak bisa ditukar sebagian atau keseluruhan dengan objek lain manapun.</li>
  </ol>
  </li>
  <li> <b>INFORMASI</b>
  <ol>
	<li>IBID <b>tidak membantu</b> pemenang lelang untuk pengiriman gadget <b>luar kota <!--dan apabila terjadi kerusakan bukan tanggung jawab IBID--></b>.</li> 
	<li>Untuk pemenang <b>dalam kota</b> silahkan <b>diambil sendiri</b> di kantor IBID.</li> 
	<!--<li>Pengambilan unit</li>
	<li>Pengambilan Unit yang dimenangkan, harus membawa <b>PRINT OUT</b> konfirmasi pemenang lelang dan FC KTP.</li> -->
        <li><b>Setiap gadget yang telah keluar dari kantor IBID tidak menjadi tanggung jawab IBID untuk itu mohon agar diperiksa secara detail dan seksama.</b></li>
  </ol>
  <ol>
  		Email : info.ibid@ibid.astra.co.id Telp. (021) 735.59.99 Fax. (021) 7289.55.66
  </ol>
  </li>
</ol>

				</div> 
		   </div> 
	 </div> 
</div> 