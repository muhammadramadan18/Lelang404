<?php $this->load->view('header'); ?>



    <div class="main">
        <div class="main-inner">
            <div class="container">
                <div class="content">
                    


                    <div class="row">
    <div class="col-sm-12 ">
       
        <table class='table table-bordered table-striped'>
<tr><td><div align="center"><span class="style3">Petunjuk bermain di PondokSoft</span></div></td>
</tr>
<tr><td><p > 
 
        Sebelum anda mendownload semua aplikasi ikuti petunjuk di bawah ini : 
        Terdapat 3 kategori download yaitu premium, member, free. 
        Untuk kategori free anda bisa mendownload semua aplikasi tanpa batas dan tidak perlu manjadi member kami,
        untuk kategori member, anda harus mendaftar from member di <a href="index.php/register">sini</a> 
        setelah mendaftar lakukan donasi seiklasnya untuk mengaktifkan akun anda, maka kategori member bisa anda download semua kecuali premium,
        kategori premium hanya bisa di download dengan harga yang tertera tanpa anda harus menjadi member.
        <br/>
        Terimakasih 


    </p>
</table>

    </div><!-- /.col-sm-4 -->
</div><!-- /.row -->

                </div><!-- /.content -->
            </div><!-- /.container -->
        </div><!-- /.main-inner -->
    </div><!-- /.main -->

<?php $this->load->view('footer'); ?>
