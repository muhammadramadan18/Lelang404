
  		<!--banner-->	
		    <div class="banner"> 
		   
				<h2> 
				<a href="index.html">Home</a> 
				<i class="fa fa-angle-right"></i> 
				<span>Dashboard</span> 
				</h2> 
		    </div> 
		<!--//banner--> 
		<!--content--> 
		<div class="content-top"> 
			<center>
				<h2>
					SELAMAT DATANG ADMIN TUKANG LELANG
				</h2>
			</center>
			
		</div> 
		<!----> 
	
  
		<div class="content-mid"> 
			
			<div class="col-md-5"> 
			  
			<link rel="stylesheet" href="css/clndr.css" type="text/css" /> 
			<script src="js/underscore-min.js" type="text/javascript"></script> 
			<script src= "js/moment-2.2.1.js" type="text/javascript"></script> 
			<script src="js/clndr.js" type="text/javascript"></script> 
			<script src="js/site.js" type="text/javascript"></script> 
			
			